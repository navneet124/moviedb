package com.moviedb.themoviedb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThemoviedbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThemoviedbApplication.class, args);
	}

}
