package com.moviedb.themoviedb.service;

import java.util.Collections;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class SearchService 
{
	public ResponseEntity<String> byActorName(String person)
	{
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.set("APIKey", "3e0438d7515da1eaf277b9a308bbc7a5");
			headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			String resourceURL = "https://api.themoviedb.org/3/search/person?api_key=3e0438d7515da1eaf277b9a308bbc7a5&query="+person;
			HttpEntity<String> entity = new HttpEntity<String>(headers);
			
			ResponseEntity<String> response = restTemplate.exchange(resourceURL, HttpMethod.GET, entity, String.class);
			
			return response;
	}
	public ResponseEntity<String> byMovieName(String keyword)
	{
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.set("APIKey", "3e0438d7515da1eaf277b9a308bbc7a5");
			headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			String resourceURL = "https://api.themoviedb.org/3/search/movie?api_key=3e0438d7515da1eaf277b9a308bbc7a5&query="+keyword;
			HttpEntity<String> entity = new HttpEntity<String>(headers);
			
			ResponseEntity<String> response = restTemplate.exchange(resourceURL, HttpMethod.GET, entity, String.class);
			return response;
	}
	
}
