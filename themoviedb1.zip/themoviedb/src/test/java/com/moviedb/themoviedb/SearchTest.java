package com.moviedb.themoviedb;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Collections;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;

import com.moviedb.themoviedb.contoller.FrontController;

public class SearchTest 
{
	@InjectMocks
    private FrontController frontController;
 
    private MockMvc mockMvc;
 
    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(frontController).build();
    }
    @Test
    public void trendingmoviestest() throws Exception {
        this.mockMvc.perform(get("/trending")).andExpect(status().isOk());
    }
    @Test
    public void upcomingmoviestest() throws Exception {
        this.mockMvc.perform(get("/upcoming")).andExpect(status().isOk());
    }
    @Test
    public void searchbymovienametest() throws Exception {
        this.mockMvc.perform(get("/search-movietitle/Men in Black: International")).andExpect(status().isOk());
    }
    @Test
    public void searchbypersontest() throws Exception {
        this.mockMvc.perform(get("/search-actor/Salman Khan")).andExpect(status().isOk());
    }
    
    @Test
    public void upcomingmoviestest1() throws Exception
    {
    	RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		String apikey = "3e0438d7515da1eaf277b9a308bbc7a5";
		if(apikey.equals("3e0438d7515da1eaf277b9a308bbc7a5"))
			headers.set("APIKey", apikey);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		String resourceURL = "https://api.themoviedb.org/3/trending/all/day?api_key=3e0438d7515da1eaf277b9a308bbc7a5";
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		
		ResponseEntity<String> response = restTemplate.exchange(resourceURL, HttpMethod.GET, entity, String.class);
		assertTrue(response.toString(), true);
    }
    @Test
    public void trendingmoviestest1() throws Exception
    {
    	RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		String apikey = "3e0438d7515da1eaf277b9a308bbc7a5";
		if(apikey.equals("3e0438d7515da1eaf277b9a308bbc7a5"))
			headers.set("APIKey", apikey);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		String resourceURL = "https://api.themoviedb.org/3/movie/upcoming?api_key=3e0438d7515da1eaf277b9a308bbc7a5";
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		
		ResponseEntity<String> response = restTemplate.exchange(resourceURL, HttpMethod.GET, entity, String.class);
		assertTrue(response.toString(), true);
    }
    @Test
    public void byActorNametest() throws Exception
    {
    	String person ="Salman Khan";
    	RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		String apikey = "3e0438d7515da1eaf277b9a308bbc7a5";
		if(apikey.equals("3e0438d7515da1eaf277b9a308bbc7a5"))
			headers.set("APIKey", apikey);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		String resourceURL = "https://api.themoviedb.org/3/search/person?api_key=3e0438d7515da1eaf277b9a308bbc7a5&query="+person;
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		
		ResponseEntity<String> response = restTemplate.exchange(resourceURL, HttpMethod.GET, entity, String.class);
		assertTrue(response.toString(), true);
    }
    @Test
    public void byMovieNametest() throws Exception
    {
    	String keyword ="Men in Black: International";
    	RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		String apikey = "3e0438d7515da1eaf277b9a308bbc7a5";
		if(apikey.equals("3e0438d7515da1eaf277b9a308bbc7a5"))
			headers.set("APIKey", apikey);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		String resourceURL = "https://api.themoviedb.org/3/search/movie?api_key=3e0438d7515da1eaf277b9a308bbc7a5&query="+keyword;
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		
		ResponseEntity<String> response = restTemplate.exchange(resourceURL, HttpMethod.GET, entity, String.class);
		assertTrue(response.toString(), true);
    }
    
}
